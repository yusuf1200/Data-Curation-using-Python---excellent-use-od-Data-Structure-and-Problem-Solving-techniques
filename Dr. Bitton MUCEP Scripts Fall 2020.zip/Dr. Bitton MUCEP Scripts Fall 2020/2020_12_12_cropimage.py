from PIL import Image
import os

# Selects the directory of images
directory = "Aug_17"
print(directory)

# loop each file in the directory
for filename in os.listdir(directory):
    # only handle image files (add as necessary), ignore rest
    if filename.endswith(".JPG"):
        print(filename)
        im = Image.open(directory+"/"+filename)

        # crop
        region = im.crop((1372, 0, 5472, 3648))

        # output directory
        outputDir = directory + "_output"

        # if output directory doesn't exist, create new
        if (not os.path.exists(outputDir)):
            os.mkdir(outputDir)

        # save
        region.save(outputDir + "/" + filename)
    else:
        continue
