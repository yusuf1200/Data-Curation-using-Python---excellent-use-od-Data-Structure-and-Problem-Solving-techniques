import os
import csv
from shutil import copyfile
import random
import math


# functions

# insert a random row from sourceList to destinationList
def insertRandomRows(sourceList, destinationList, numRows):
    i = 0
    while i < numRows:
        pickRow = random.choice(sourceList)
        # make sure background is not same
        same = False
        for val in destinationList:
            sourceBackground = pickRow[3]
            if (val[3] == sourceBackground):
                same = True
        if (same == False):
            row = pickRow
            destinationList.append(row)
            i += 1

# reorder list without duplicates


def shuffle_list(some_list):
    randomized_list = some_list[:]
    while True:
        random.shuffle(randomized_list)
        for a, b in zip(some_list, randomized_list):
            if a == b:
                break
        else:
            return randomized_list


def writeCsvFile(path, rowsList, header, mothDirectory):

    # index
    global mothCount
    with open(path, 'w', newline='') as csvfile:
        fieldnames = header
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        # list of rows
        for i in range(len(rowsList)):
            # print(rowsList[i])

            # background field
            background = rowsList[i][3]+'BACK.png'
            # moth image
            moth = str(mothCount) + rowsList[i][2] + '_' + \
                rowsList[i][0]+'_'+rowsList[i][1]+'.png'
            mothCount += 1
            # coordinates of image
            randomY = math.floor(random.uniform(31.5, 1080-31.5)*10)/10
            randomX = math.floor(random.uniform(63, 1920-63)*10)/10

            # write in csv
            writer.writerow(
                {fieldnames[0]: i+1, fieldnames[1]: background, fieldnames[2]: moth, fieldnames[3]: randomX, fieldnames[4]: randomY})

            # place file in directory
            copyfile('moths/' + rowsList[i][0] + '/' +
                     rowsList[i][1]+'.png', mothDirectory + moth)


# Pick 100 rows from matches.csv file
for j in range(100):
    mothCount = 1

    treatmentB = []
    p1 = []  # 1P 16 rows

    treatmentA = []
    tb = []  # 1TB1 and 1TB2 42 rows

    # Reading csv
    with open('matches.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',', quotechar='|')
        for row in reader:
            if (row[2] == 'B'):
                # Insert B treatment in treatmentB list
                treatmentB.append(row)
            elif (row[2] == 'A'):
                # Insert A treatment in treatmentA list
                treatmentA.append(row)

    # insert a random row from the list of treatmentB
    insertRandomRows(treatmentB, p1, 16)

    # name of directories
    mothDirectory = 'output/Participant ' + \
        str(j+1) + '/Moths ' + str(j+1) + '/'
    csvDirectory = 'output/Participant ' + \
        str(j+1) + '/Conditions ' + str(j+1) + '/'

    # create directory if doesn't exist
    if not os.path.exists(mothDirectory):
        os.makedirs(mothDirectory)
    if not os.path.exists(csvDirectory):
        os.makedirs(csvDirectory)

    # write in csv file
    writeCsvFile(csvDirectory + str(j+1)+'P.csv', p1,
                 ['Trial_Number', 'Background', 'Moth', 'X', 'Y'], mothDirectory
                 )

    # 1TB1 and 1TB2
    insertRandomRows(treatmentA, tb, 42)
    writeCsvFile(csvDirectory + str(j+1)+'TB1.csv', tb[:21],
                 ['Trial_Number_1', 'Background_1',
                     'Moth_1', 'X_1', 'Y_1'], mothDirectory
                 )
    writeCsvFile(csvDirectory + str(j+1)+'TB2.csv', tb[21:],
                 ['Trial_Number_2', 'Background_2',
                     'Moth_2', 'X_2', 'Y_2'], mothDirectory
                 )

    # 1TB3 and 1TB4
    tb3 = tb[:21]
    # random.shuffle(tb3)
    tb3 = shuffle_list(tb3)

    writeCsvFile(csvDirectory + str(j+1)+'TB3.csv', tb3,
                 ['Trial_Number_3', 'Background_3',
                     'Moth_3', 'X_3', 'Y_3'], mothDirectory
                 )

    tb4 = tb[21:]
    # random.shuffle(tb4)
    tb4 = shuffle_list(tb4)
    writeCsvFile(csvDirectory + str(j+1) + 'TB4.csv', tb4,
                 ['Trial_Number_4', 'Background_4',
                     'Moth_4', 'X_4', 'Y_4'], mothDirectory
                 )


print("Done.")
