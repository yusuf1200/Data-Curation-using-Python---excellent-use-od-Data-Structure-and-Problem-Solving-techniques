------------------------------------------------------------------------
                      2020_12_12_cropimage.py
------------------------------------------------------------------------

PROJECT TITLE: Image Analysis

PURPOSE OF PROJECT: MUCEP (Dr Pierre-Paul Bitton)

STUDENT NAME : Yusuf Alam 

STUDENT NUMBER ; 201759321

USER INSTRUCTIONS HOW TO RUN :

1. Ensure folder hierarchy is maintained.
2  Run the file  2020_12_12_cropimage.py with having the image directory in the same file where the python program exists. for example in our case an example of a directory is (Aug_17)
3. The resulting files from the program will be a directory named as Aug_17_output
4. Open Aug_17_output to see results.
5. the code line #crop takes in the co-ordinates that can me modified to decide on setting the image size as necessary.
